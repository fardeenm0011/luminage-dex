import React from "react";
import WinnerCardComponent from "./WinnerCardComponent";

const Leaderboard = () => {
  return (
    <>
      <WinnerCardComponent username="Yash" imageUrl="none" />
    </>
  );
};

export default Leaderboard;
